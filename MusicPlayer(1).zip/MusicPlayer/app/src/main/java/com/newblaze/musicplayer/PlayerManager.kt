package com.newblaze.musicplayer

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri

class PlayerManager(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    var currentSong: Song? = null
        private set

    fun play(song: Song) {
        stop()
        currentSong = song
        mediaPlayer = MediaPlayer().apply {
            setDataSource(context, Uri.parse(song.uriString))
            prepare()
            start()
        }
    }

    fun pause() {
        mediaPlayer?.takeIf { it.isPlaying }?.pause()
    }

    fun resume() {
        mediaPlayer?.takeIf { !it.isPlaying }?.start()
    }

    fun isPlaying(): Boolean = mediaPlayer?.isPlaying == true

    fun stop() {
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
