package com.newblaze.musicplayer

import android.Manifest
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.newblaze.musicplayer.databinding.ActivityMainBinding
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var musicService: MusicService? = null
    private var serviceBound = false

    private var allSongs: List<Song> = emptyList()
    private var displayedSongs: List<Song> = emptyList()
    private var songAdapter: SongAdapter? = null

    private val progressHandler = Handler(Looper.getMainLooper())
    private var progressRunnable: Runnable? = null
    private var isUserSeeking = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as MusicService.LocalBinder
            musicService = binder.getService()
            serviceBound = true
            musicService?.listener = playbackListener

            if (allSongs.isNotEmpty()) {
                musicService?.setPlaylist(allSongs)
            }
            startProgressUpdates()
            refreshFromService()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            musicService = null
        }
    }

    private val playbackListener = object : MusicService.PlaybackListener {
        override fun onSongChanged(song: Song?, index: Int) {
            runOnUiThread { updateNowPlayingUi(song) }
        }

        override fun onPlaybackStateChanged(isPlaying: Boolean) {
            runOnUiThread {
                binding.buttonPlayPause.setImageResource(
                    if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                )
            }
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            val audioGranted = results.entries.any {
                (it.key == Manifest.permission.READ_MEDIA_AUDIO || it.key == Manifest.permission.READ_EXTERNAL_STORAGE) && it.value
            }
            if (audioGranted) {
                loadSongs()
            } else {
                binding.textStatus.text = "Autorisation refusée : impossible d'accéder à ta musique."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        MobileAds.initialize(this) {}
        binding.adView.loadAd(AdRequest.Builder().build())

        binding.recyclerSongs.layoutManager = LinearLayoutManager(this)

        checkPermissionAndLoad()

        binding.buttonPlayPause.setOnClickListener { musicService?.togglePlayPause() }
        binding.buttonNext.setOnClickListener { musicService?.playNext() }
        binding.buttonPrevious.setOnClickListener { musicService?.playPrevious() }
        binding.buttonOpenPlaylists.setOnClickListener {
            startActivity(Intent(this, PlaylistsActivity::class.java))
        }

        binding.editSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterSongs(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) binding.textElapsed.text = formatDuration(progress.toLong())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = false
                musicService?.seekTo(seekBar?.progress ?: 0)
            }
        })

        val serviceIntent = Intent(this, MusicService::class.java)
        startService(serviceIntent)
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun checkPermissionAndLoad() {
        val permissions = mutableListOf<String>()
        permissions.add(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                Manifest.permission.READ_MEDIA_AUDIO
            else
                Manifest.permission.READ_EXTERNAL_STORAGE
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val allGranted = permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

        if (allGranted) {
            loadSongs()
        } else {
            requestPermissionLauncher.launch(permissions.toTypedArray())
        }
    }

    private fun loadSongs() {
        allSongs = MusicRepository.getAllSongs(this)
        displayedSongs = allSongs

        if (allSongs.isEmpty()) {
            binding.textStatus.text = "Aucune musique trouvée sur ce téléphone."
            return
        }

        binding.textStatus.text = "${allSongs.size} morceau(x) trouvé(s)"

        songAdapter = SongAdapter(
            displayedSongs,
            onSongClick = { song ->
                val index = allSongs.indexOf(song)
                if (index != -1) {
                    musicService?.setPlaylist(allSongs)
                    musicService?.playAt(index)
                }
            },
            onAddToPlaylistClick = { song -> showAddToPlaylistDialog(song) }
        )
        binding.recyclerSongs.adapter = songAdapter

        musicService?.setPlaylist(allSongs)
    }

    private fun filterSongs(query: String) {
        displayedSongs = if (query.isBlank()) {
            allSongs
        } else {
            val lower = query.trim().lowercase()
            allSongs.filter {
                it.title.lowercase().contains(lower) || it.artist.lowercase().contains(lower)
            }
        }
        songAdapter?.updateData(displayedSongs)
    }

    private fun showAddToPlaylistDialog(song: Song) {
        val playlists = PlaylistRepository.getAll(this)
        val options = playlists.map { it.name }.toMutableList()
        options.add(getString(R.string.create_new_playlist_option))

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.add_to_playlist_dialog_title))
            .setItems(options.toTypedArray()) { _, which ->
                if (which == options.size - 1) {
                    showCreatePlaylistThenAdd(song)
                } else {
                    val playlist = playlists[which]
                    PlaylistRepository.addSongToPlaylist(this, playlist.id, song.id)
                    Toast.makeText(this, getString(R.string.song_added_to_playlist), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun showCreatePlaylistThenAdd(song: Song) {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.new_playlist_dialog_title))
            .setView(input)
            .setPositiveButton(getString(R.string.ok)) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val playlist = PlaylistRepository.createPlaylist(this, name)
                    PlaylistRepository.addSongToPlaylist(this, playlist.id, song.id)
                    Toast.makeText(this, getString(R.string.song_added_to_playlist), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun refreshFromService() {
        val service = musicService ?: return
        val song = service.getCurrentSong()
        if (song != null) {
            updateNowPlayingUi(song)
            binding.buttonPlayPause.setImageResource(
                if (service.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
            )
        }
    }

    private fun updateNowPlayingUi(song: Song?) {
        if (song == null) return
        binding.textNowPlayingTitle.text = song.title
        binding.textNowPlayingArtist.text = song.artist
        binding.seekBar.max = song.duration.toInt().coerceAtLeast(1)
        binding.textTotal.text = formatDuration(song.duration)

        val art = AlbumArtLoader.load(this, song.albumId)
        if (art != null) {
            binding.imageAlbumArt.setImageBitmap(art)
        } else {
            binding.imageAlbumArt.setImageResource(R.drawable.ic_music_note)
        }

        songAdapter?.setPlayingSongId(song.id)
    }

    private fun startProgressUpdates() {
        progressRunnable = object : Runnable {
            override fun run() {
                val service = musicService
                if (service != null && !isUserSeeking) {
                    val position = service.getCurrentPosition()
                    binding.seekBar.progress = position
                    binding.textElapsed.text = formatDuration(position.toLong())
                }
                progressHandler.postDelayed(this, 500)
            }
        }
        progressHandler.post(progressRunnable!!)
    }

    private fun formatDuration(millis: Long): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
        return String.format("%d:%02d", minutes, seconds)
    }

    override fun onResume() {
        super.onResume()
        // Les playlists ont pu changer pendant qu'on était sur un autre écran
        refreshFromService()
    }

    override fun onDestroy() {
        super.onDestroy()
        progressRunnable?.let { progressHandler.removeCallbacks(it) }
        if (serviceBound) {
            musicService?.listener = null
            unbindService(serviceConnection)
            serviceBound = false
        }
    }
}
