package com.newblaze.musicplayer

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.newblaze.musicplayer.databinding.ItemPlaylistSongBinding

class PlaylistSongAdapter(
    private var songs: List<Song>,
    private val onSongClick: (Song) -> Unit,
    private val onRemoveClick: (Song) -> Unit
) : RecyclerView.Adapter<PlaylistSongAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemPlaylistSongBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPlaylistSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val song = songs[position]
        holder.binding.textTitle.text = song.title
        holder.binding.textArtist.text = song.artist

        val art = AlbumArtLoader.load(holder.binding.root.context, song.albumId)
        if (art != null) {
            holder.binding.imageAlbumArt.setImageBitmap(art)
        } else {
            holder.binding.imageAlbumArt.setImageResource(R.drawable.ic_music_note)
        }

        holder.binding.root.setOnClickListener { onSongClick(song) }
        holder.binding.buttonRemove.setOnClickListener { onRemoveClick(song) }
    }

    override fun getItemCount() = songs.size

    fun updateData(newSongs: List<Song>) {
        songs = newSongs
        notifyDataSetChanged()
    }
}
