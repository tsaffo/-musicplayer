package com.newblaze.musicplayer

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.newblaze.musicplayer.databinding.ActivityPlaylistsBinding

class PlaylistsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlaylistsBinding
    private lateinit var adapter: PlaylistAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlaylistsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonBack.setOnClickListener { finish() }

        binding.recyclerPlaylists.layoutManager = LinearLayoutManager(this)
        adapter = PlaylistAdapter(
            emptyList(),
            onClick = { playlist ->
                val intent = Intent(this, PlaylistDetailActivity::class.java)
                intent.putExtra("playlist_id", playlist.id)
                startActivity(intent)
            },
            onDelete = { playlist ->
                PlaylistRepository.deletePlaylist(this, playlist.id)
                refreshList()
            }
        )
        binding.recyclerPlaylists.adapter = adapter

        binding.fabAddPlaylist.setOnClickListener { showCreatePlaylistDialog() }
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun refreshList() {
        val playlists = PlaylistRepository.getAll(this)
        adapter.updateData(playlists)
        binding.textEmpty.visibility = if (playlists.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun showCreatePlaylistDialog() {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.new_playlist_dialog_title))
            .setView(input)
            .setPositiveButton(getString(R.string.ok)) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    PlaylistRepository.createPlaylist(this, name)
                    refreshList()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
}
