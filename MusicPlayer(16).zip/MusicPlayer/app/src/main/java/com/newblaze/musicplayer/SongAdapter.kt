package com.newblaze.musicplayer

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.newblaze.musicplayer.databinding.ItemSongBinding
import java.util.concurrent.TimeUnit

class SongAdapter(
    private var songs: List<Song>,
    private val onSongClick: (Song) -> Unit,
    private val onAddToPlaylistClick: (Song) -> Unit
) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    private var playingSongId: Long = -1

    inner class SongViewHolder(val binding: ItemSongBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val binding = ItemSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SongViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val song = songs[position]
        holder.binding.textTitle.text = song.title
        holder.binding.textArtist.text = song.artist
        holder.binding.textDuration.text = formatDuration(song.duration)

        val art = AlbumArtLoader.load(holder.binding.root.context, song.albumId)
        if (art != null) {
            holder.binding.imageAlbumArt.setImageBitmap(art)
        } else {
            holder.binding.imageAlbumArt.setImageResource(R.drawable.ic_music_note)
        }

        holder.binding.root.setBackgroundColor(
            if (song.id == playingSongId)
                holder.binding.root.context.getColor(R.color.playing_highlight)
            else
                Color.TRANSPARENT
        )

        holder.binding.root.setOnClickListener { onSongClick(song) }
        holder.binding.buttonAddToPlaylist.setOnClickListener { onAddToPlaylistClick(song) }
    }

    override fun getItemCount() = songs.size

    fun updateData(newSongs: List<Song>) {
        songs = newSongs
        notifyDataSetChanged()
    }

    fun setPlayingSongId(songId: Long) {
        playingSongId = songId
        notifyDataSetChanged()
    }

    private fun formatDuration(millis: Long): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
        return String.format("%d:%02d", minutes, seconds)
    }
}
