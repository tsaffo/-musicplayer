package com.newblaze.musicplayer

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.newblaze.musicplayer.databinding.ActivityPlaylistDetailBinding

class PlaylistDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlaylistDetailBinding
    private lateinit var adapter: PlaylistSongAdapter

    private var playlistId: String = ""
    private var playlistSongs: List<Song> = emptyList()

    private var musicService: MusicService? = null
    private var serviceBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as MusicService.LocalBinder
            musicService = binder.getService()
            serviceBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            musicService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlaylistDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        playlistId = intent.getStringExtra("playlist_id") ?: ""

        binding.buttonBack.setOnClickListener { finish() }
        binding.recyclerPlaylistSongs.layoutManager = LinearLayoutManager(this)

        adapter = PlaylistSongAdapter(
            emptyList(),
            onSongClick = { song -> playFromPlaylist(song) },
            onRemoveClick = { song ->
                PlaylistRepository.removeSongFromPlaylist(this, playlistId, song.id)
                loadPlaylistSongs()
            }
        )
        binding.recyclerPlaylistSongs.adapter = adapter

        binding.buttonPlayAll.setOnClickListener {
            if (playlistSongs.isNotEmpty()) {
                playFromPlaylist(playlistSongs[0])
            }
        }

        val serviceIntent = Intent(this, MusicService::class.java)
        startService(serviceIntent)
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE)

        loadPlaylistSongs()
    }

    private fun loadPlaylistSongs() {
        val playlist = PlaylistRepository.getById(this, playlistId)
        if (playlist == null) {
            finish()
            return
        }

        binding.textPlaylistTitle.text = playlist.name

        val allSongs = MusicRepository.getAllSongs(this)
        // On garde l'ordre défini dans la playlist
        playlistSongs = playlist.songIds.mapNotNull { id -> allSongs.find { it.id == id } }

        adapter.updateData(playlistSongs)
        binding.textEmpty.visibility = if (playlistSongs.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun playFromPlaylist(song: Song) {
        val index = playlistSongs.indexOf(song)
        if (index == -1) return
        musicService?.setPlaylist(playlistSongs)
        musicService?.playAt(index)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (serviceBound) {
            unbindService(serviceConnection)
            serviceBound = false
        }
    }
}
