package com.newblaze.musicplayer

data class Playlist(
    val id: String,
    var name: String,
    val songIds: MutableList<Long>
)
