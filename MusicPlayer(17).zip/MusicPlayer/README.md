# MusicPlayer — com.newblaze.musicplayer

Lecteur de musique locale pour Android (Kotlin), type VLC, avec bannière AdMob intégrée.

## Fonctionnalités actuelles

- Scan de tous les fichiers audio du téléphone (MediaStore)
- Liste des morceaux avec pochette d'album, titre, artiste, durée
- **Lecture en arrière-plan** via un `Service` Android : la musique continue même
  app fermée ou écran verrouillé
- **Notification de contrôle** (précédent / lecture-pause / suivant), y compris sur
  l'écran de verrouillage, grâce à une `MediaSession`
- **Seekbar** : voir et déplacer la progression du morceau en cours
- **Playlist** : bouton suivant/précédent, passage automatique au morceau suivant
  à la fin de chaque piste, morceau en cours surligné dans la liste
- **Pochettes d'album** récupérées automatiquement, avec une icône par défaut si absentes
- Bannière publicitaire AdMob en bas de l'écran (actuellement en **ID de test**)

## Comment ouvrir ce projet

1. Installe [Android Studio](https://developer.android.com/studio) si ce n'est pas déjà fait
2. Ouvre Android Studio → "Open" → sélectionne le dossier `MusicPlayer`
3. Laisse Gradle synchroniser (ça peut prendre quelques minutes la première fois —
   Android Studio complète automatiquement les fichiers du wrapper Gradle manquants)
4. Branche un téléphone Android en mode débogage USB, ou lance un émulateur
5. Clique sur "Run" (▶️)
6. Autorise l'accès à la musique et aux notifications quand l'app le demande

## Avant de publier sur le Play Store — passage en production AdMob

Le projet utilise actuellement les **ID de test officiels de Google** (aucun risque
pour ton compte, mais aucun revenu réel non plus). Pour passer en production :

1. Crée un compte sur [admob.google.com](https://admob.google.com)
2. Enregistre l'application et crée un bloc publicitaire de type "Bannière"
3. Remplace les deux ID de test par les tiens :
   - Dans `app/src/main/AndroidManifest.xml` → la valeur du `meta-data`
     `com.google.android.gms.ads.APPLICATION_ID`
   - Dans `app/src/main/res/layout/activity_main.xml` → `app:adUnitId` de l'`AdView`
4. Ne clique jamais toi-même sur tes propres pubs en production (violation des
   règles Google, risque de bannissement du compte)

## Prochaines améliorations possibles

- Création et gestion de playlists personnalisées
- Recherche et tri (par artiste, album, date d'ajout)
- Mode aléatoire / répétition
- Égaliseur audio
- Passer à des formats publicitaires additionnels (interstitiel entre certaines
  actions, vidéo récompensée pour débloquer un thème par exemple) — à faire avec
  prudence pour ne pas nuire à l'expérience d'écoute

## Structure du projet

```
MusicPlayer/
  app/
    src/main/
      java/com/newblaze/musicplayer/
        MainActivity.kt       -> écran principal, permissions, AdMob, liaison au service
        MusicService.kt        -> lecture en arrière-plan, notification, MediaSession
        Song.kt                 -> modèle de données d'un morceau
        MusicRepository.kt      -> scan de la musique du téléphone
        SongAdapter.kt          -> affichage de la liste des morceaux
        AlbumArtLoader.kt        -> chargement + cache des pochettes d'album
      res/
        layout/                -> écrans (XML)
        values/                 -> textes, couleurs, thème
        drawable/                -> icônes des contrôles de lecture
      AndroidManifest.xml
    build.gradle.kts
  build.gradle.kts
  settings.gradle.kts
```
