package com.newblaze.musicplayer

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val duration: Long,
    val uriString: String,
    val albumId: Long
)
