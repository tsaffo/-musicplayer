package com.newblaze.musicplayer

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.util.Size

/**
 * Charge la pochette d'un album à partir de son albumId, avec un petit cache
 * en mémoire pour éviter de redécoder la même image plusieurs fois
 * (utile car beaucoup de morceaux partagent le même album).
 */
object AlbumArtLoader {

    private val cache = HashMap<Long, Bitmap?>()

    fun load(context: Context, albumId: Long): Bitmap? {
        if (cache.containsKey(albumId)) {
            return cache[albumId]
        }

        val bitmap = try {
            val albumArtUri = ContentUris.withAppendedId(
                Uri.parse("content://media/external/audio/albumart"),
                albumId
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.loadThumbnail(albumArtUri, Size(300, 300), null)
            } else {
                @Suppress("DEPRECATION")
                android.provider.MediaStore.Images.Media.getBitmap(context.contentResolver, albumArtUri)
            }
        } catch (e: Exception) {
            // Pas de pochette pour cet album, ou erreur de lecture : on retombera sur l'icône par défaut
            null
        }

        cache[albumId] = bitmap
        return bitmap
    }
}
