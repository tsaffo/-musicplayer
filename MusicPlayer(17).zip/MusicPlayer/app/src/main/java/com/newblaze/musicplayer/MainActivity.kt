package com.newblaze.musicplayer

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.newblaze.musicplayer.databinding.ActivityMainBinding
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var musicService: MusicService? = null
    private var serviceBound = false

    private var songs: List<Song> = emptyList()
    private var songAdapter: SongAdapter? = null

    private val progressHandler = Handler(Looper.getMainLooper())
    private var progressRunnable: Runnable? = null
    private var isUserSeeking = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as MusicService.LocalBinder
            musicService = binder.getService()
            serviceBound = true
            musicService?.listener = playbackListener

            if (songs.isNotEmpty()) {
                musicService?.setPlaylist(songs)
            }
            startProgressUpdates()
            refreshFromService()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            musicService = null
        }
    }

    private val playbackListener = object : MusicService.PlaybackListener {
        override fun onSongChanged(song: Song?, index: Int) {
            runOnUiThread { updateNowPlayingUi(song, index) }
        }

        override fun onPlaybackStateChanged(isPlaying: Boolean) {
            runOnUiThread {
                binding.buttonPlayPause.setImageResource(
                    if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                )
            }
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            val audioGranted = results.entries.any {
                (it.key == Manifest.permission.READ_MEDIA_AUDIO || it.key == Manifest.permission.READ_EXTERNAL_STORAGE) && it.value
            }
            if (audioGranted) {
                loadSongs()
            } else {
                binding.textStatus.text = "Autorisation refusée : impossible d'accéder à ta musique."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        MobileAds.initialize(this) {}
        binding.adView.loadAd(AdRequest.Builder().build())

        binding.recyclerSongs.layoutManager = LinearLayoutManager(this)

        checkPermissionAndLoad()

        binding.buttonPlayPause.setOnClickListener { musicService?.togglePlayPause() }
        binding.buttonNext.setOnClickListener { musicService?.playNext() }
        binding.buttonPrevious.setOnClickListener { musicService?.playPrevious() }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) binding.textElapsed.text = formatDuration(progress.toLong())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = false
                musicService?.seekTo(seekBar?.progress ?: 0)
            }
        })

        val serviceIntent = Intent(this, MusicService::class.java)
        startService(serviceIntent)
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun checkPermissionAndLoad() {
        val permissions = mutableListOf<String>()
        permissions.add(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                Manifest.permission.READ_MEDIA_AUDIO
            else
                Manifest.permission.READ_EXTERNAL_STORAGE
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val allGranted = permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

        if (allGranted) {
            loadSongs()
        } else {
            requestPermissionLauncher.launch(permissions.toTypedArray())
        }
    }

    private fun loadSongs() {
        songs = MusicRepository.getAllSongs(this)

        if (songs.isEmpty()) {
            binding.textStatus.text = "Aucune musique trouvée sur ce téléphone."
            return
        }

        binding.textStatus.text = "${songs.size} morceau(x) trouvé(s)"

        songAdapter = SongAdapter(songs) { index ->
            musicService?.setPlaylist(songs)
            musicService?.playAt(index)
        }
        binding.recyclerSongs.adapter = songAdapter

        musicService?.setPlaylist(songs)
    }

    private fun refreshFromService() {
        val service = musicService ?: return
        val song = service.getCurrentSong()
        if (song != null) {
            updateNowPlayingUi(song, service.getCurrentIndex())
            binding.buttonPlayPause.setImageResource(
                if (service.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
            )
        }
    }

    private fun updateNowPlayingUi(song: Song?, index: Int) {
        if (song == null) return
        binding.textNowPlayingTitle.text = song.title
        binding.textNowPlayingArtist.text = song.artist
        binding.seekBar.max = song.duration.toInt().coerceAtLeast(1)
        binding.textTotal.text = formatDuration(song.duration)

        val art = AlbumArtLoader.load(this, song.albumId)
        if (art != null) {
            binding.imageAlbumArt.setImageBitmap(art)
        } else {
            binding.imageAlbumArt.setImageResource(R.drawable.ic_music_note)
        }

        songAdapter?.setPlayingIndex(index)
    }

    private fun startProgressUpdates() {
        progressRunnable = object : Runnable {
            override fun run() {
                val service = musicService
                if (service != null && !isUserSeeking) {
                    val position = service.getCurrentPosition()
                    binding.seekBar.progress = position
                    binding.textElapsed.text = formatDuration(position.toLong())
                }
                progressHandler.postDelayed(this, 500)
            }
        }
        progressHandler.post(progressRunnable!!)
    }

    private fun formatDuration(millis: Long): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
        return String.format("%d:%02d", minutes, seconds)
    }

    override fun onDestroy() {
        super.onDestroy()
        progressRunnable?.let { progressHandler.removeCallbacks(it) }
        if (serviceBound) {
            musicService?.listener = null
            unbindService(serviceConnection)
            serviceBound = false
        }
    }
}
