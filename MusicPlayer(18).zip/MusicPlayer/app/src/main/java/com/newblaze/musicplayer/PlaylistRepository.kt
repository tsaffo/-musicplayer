package com.newblaze.musicplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object PlaylistRepository {

    private const val PREFS_NAME = "vibe_player_playlists"
    private const val KEY_PLAYLISTS = "playlists_json"

    fun getAll(context: Context): MutableList<Playlist> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_PLAYLISTS, null) ?: return mutableListOf()

        val result = mutableListOf<Playlist>()
        val array = JSONArray(json)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val idsArray = obj.getJSONArray("songIds")
            val ids = mutableListOf<Long>()
            for (j in 0 until idsArray.length()) {
                ids.add(idsArray.getLong(j))
            }
            result.add(Playlist(obj.getString("id"), obj.getString("name"), ids))
        }
        return result
    }

    fun getById(context: Context, playlistId: String): Playlist? {
        return getAll(context).find { it.id == playlistId }
    }

    private fun saveAll(context: Context, playlists: List<Playlist>) {
        val array = JSONArray()
        for (p in playlists) {
            val obj = JSONObject()
            obj.put("id", p.id)
            obj.put("name", p.name)
            val idsArray = JSONArray()
            p.songIds.forEach { idsArray.put(it) }
            obj.put("songIds", idsArray)
            array.put(obj)
        }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PLAYLISTS, array.toString()).apply()
    }

    fun createPlaylist(context: Context, name: String): Playlist {
        val playlists = getAll(context)
        val newPlaylist = Playlist(UUID.randomUUID().toString(), name, mutableListOf())
        playlists.add(newPlaylist)
        saveAll(context, playlists)
        return newPlaylist
    }

    fun deletePlaylist(context: Context, playlistId: String) {
        val playlists = getAll(context)
        playlists.removeAll { it.id == playlistId }
        saveAll(context, playlists)
    }

    fun addSongToPlaylist(context: Context, playlistId: String, songId: Long) {
        val playlists = getAll(context)
        val playlist = playlists.find { it.id == playlistId } ?: return
        if (!playlist.songIds.contains(songId)) {
            playlist.songIds.add(songId)
        }
        saveAll(context, playlists)
    }

    fun removeSongFromPlaylist(context: Context, playlistId: String, songId: Long) {
        val playlists = getAll(context)
        val playlist = playlists.find { it.id == playlistId } ?: return
        playlist.songIds.remove(songId)
        saveAll(context, playlists)
    }
}
