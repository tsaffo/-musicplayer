package com.newblaze.musicplayer

import android.Manifest
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.newblaze.musicplayer.databinding.ActivityMainBinding
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    companion object {
        private const val SORT_TITLE = 0
        private const val SORT_ARTIST = 1
        private const val SORT_DURATION = 2
        private const val SORT_RECENT = 3
    }

    private lateinit var binding: ActivityMainBinding

    private var musicService: MusicService? = null
    private var serviceBound = false

    private var allSongs: List<Song> = emptyList()
    private var displayedSongs: List<Song> = emptyList()
    private var songAdapter: SongAdapter? = null

    private var currentQuery: String = ""
    private var sortMode: Int = SORT_TITLE

    private val progressHandler = Handler(Looper.getMainLooper())
    private var progressRunnable: Runnable? = null
    private var isUserSeeking = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as MusicService.LocalBinder
            musicService = binder.getService()
            serviceBound = true
            musicService?.listener = playbackListener

            if (allSongs.isNotEmpty()) {
                musicService?.setPlaylist(allSongs)
            }
            startProgressUpdates()
            refreshFromService()
            updateModeIcons()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            musicService = null
        }
    }

    private val playbackListener = object : MusicService.PlaybackListener {
        override fun onSongChanged(song: Song?, index: Int) {
            runOnUiThread { updateNowPlayingUi(song) }
        }

        override fun onPlaybackStateChanged(isPlaying: Boolean) {
            runOnUiThread {
                binding.buttonPlayPause.setImageResource(
                    if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                )
            }
        }

        override fun onModesChanged(repeatMode: Int, shuffleEnabled: Boolean) {
            runOnUiThread { updateModeIcons() }
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            val audioGranted = results.entries.any {
                (it.key == Manifest.permission.READ_MEDIA_AUDIO || it.key == Manifest.permission.READ_EXTERNAL_STORAGE) && it.value
            }
            if (audioGranted) {
                loadSongs()
            } else {
                binding.textStatus.text = "Autorisation refusée : impossible d'accéder à ta musique."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        MobileAds.initialize(this) {}
        binding.adView.loadAd(AdRequest.Builder().build())

        binding.recyclerSongs.layoutManager = LinearLayoutManager(this)

        checkPermissionAndLoad()

        binding.buttonPlayPause.setOnClickListener { musicService?.togglePlayPause() }
        binding.buttonNext.setOnClickListener { musicService?.playNext() }
        binding.buttonPrevious.setOnClickListener { musicService?.playPrevious() }
        binding.buttonShuffle.setOnClickListener {
            musicService?.toggleShuffle()
            updateModeIcons()
        }
        binding.buttonRepeat.setOnClickListener {
            musicService?.cycleRepeatMode()
            updateModeIcons()
        }
        binding.buttonSleepTimer.setOnClickListener { showSleepTimerDialog() }
        binding.buttonSort.setOnClickListener { cycleSortMode() }

        binding.editSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                currentQuery = s?.toString().orEmpty()
                applyFilterAndSort()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) binding.textElapsed.text = formatDuration(progress.toLong())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = false
                musicService?.seekTo(seekBar?.progress ?: 0)
            }
        })

        setupBottomNav()

        val serviceIntent = Intent(this, MusicService::class.java)
        startService(serviceIntent)
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun setupBottomNav() {
        binding.bottomNavigation.selectedItemId = R.id.nav_library
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_library -> true
                R.id.nav_playlists -> {
                    startActivity(Intent(this, PlaylistsActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_folders -> {
                    startActivity(Intent(this, FoldersActivity::class.java))
                    finish()
                    true
                }
                else -> false
            }
        }
    }

    private fun checkPermissionAndLoad() {
        val permissions = mutableListOf<String>()
        permissions.add(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                Manifest.permission.READ_MEDIA_AUDIO
            else
                Manifest.permission.READ_EXTERNAL_STORAGE
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val allGranted = permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

        if (allGranted) {
            loadSongs()
        } else {
            requestPermissionLauncher.launch(permissions.toTypedArray())
        }
    }

    private fun loadSongs() {
        allSongs = MusicRepository.getAllSongs(this)
        displayedSongs = allSongs

        if (allSongs.isEmpty()) {
            binding.textStatus.text = "Aucune musique trouvée sur ce téléphone."
            return
        }

        binding.textStatus.text = "${allSongs.size} morceau(x) trouvé(s)"

        songAdapter = SongAdapter(
            displayedSongs,
            onSongClick = { song ->
                val index = allSongs.indexOf(song)
                if (index != -1) {
                    musicService?.setPlaylist(allSongs)
                    musicService?.playAt(index)
                }
            },
            onAddToPlaylistClick = { song -> showAddToPlaylistDialog(song) }
        )
        binding.recyclerSongs.adapter = songAdapter

        musicService?.setPlaylist(allSongs)
        applyFilterAndSort()
    }

    private fun applyFilterAndSort() {
        var list = if (currentQuery.isBlank()) {
            allSongs
        } else {
            val lower = currentQuery.trim().lowercase()
            allSongs.filter {
                it.title.lowercase().contains(lower) || it.artist.lowercase().contains(lower)
            }
        }

        list = when (sortMode) {
            SORT_TITLE -> list.sortedBy { it.title.lowercase() }
            SORT_ARTIST -> list.sortedBy { it.artist.lowercase() }
            SORT_DURATION -> list.sortedBy { it.duration }
            SORT_RECENT -> list.sortedByDescending { it.dateAdded }
            else -> list
        }

        displayedSongs = list
        songAdapter?.updateData(displayedSongs)
    }

    private fun cycleSortMode() {
        sortMode = (sortMode + 1) % 4
        val label = when (sortMode) {
            SORT_TITLE -> getString(R.string.sort_by_title)
            SORT_ARTIST -> getString(R.string.sort_by_artist)
            SORT_DURATION -> getString(R.string.sort_by_duration)
            else -> getString(R.string.sort_by_recent)
        }
        Toast.makeText(this, label, Toast.LENGTH_SHORT).show()
        applyFilterAndSort()
    }

    private fun showSleepTimerDialog() {
        val options = arrayOf(
            getString(R.string.sleep_timer_15),
            getString(R.string.sleep_timer_30),
            getString(R.string.sleep_timer_45),
            getString(R.string.sleep_timer_60),
            getString(R.string.sleep_timer_cancel)
        )
        val minutesValues = intArrayOf(15, 30, 45, 60, 0)

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.sleep_timer_title))
            .setItems(options) { _, which ->
                val minutes = minutesValues[which]
                musicService?.setSleepTimer(minutes)
                val message = if (minutes > 0) {
                    getString(R.string.sleep_timer_set, minutes)
                } else {
                    getString(R.string.sleep_timer_cancelled)
                }
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun updateModeIcons() {
        val service = musicService ?: return

        binding.buttonShuffle.setImageResource(
            if (service.isShuffleEnabled()) R.drawable.ic_shuffle_active else R.drawable.ic_shuffle
        )

        val repeatIcon = when (service.getRepeatMode()) {
            MusicService.REPEAT_ALL -> R.drawable.ic_repeat_all
            MusicService.REPEAT_ONE -> R.drawable.ic_repeat_one
            else -> R.drawable.ic_repeat_off
        }
        binding.buttonRepeat.setImageResource(repeatIcon)
    }

    private fun showAddToPlaylistDialog(song: Song) {
        val playlists = PlaylistRepository.getAll(this)
        val options = playlists.map { it.name }.toMutableList()
        options.add(getString(R.string.create_new_playlist_option))

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.add_to_playlist_dialog_title))
            .setItems(options.toTypedArray()) { _, which ->
                if (which == options.size - 1) {
                    showCreatePlaylistThenAdd(song)
                } else {
                    val playlist = playlists[which]
                    PlaylistRepository.addSongToPlaylist(this, playlist.id, song.id)
                    Toast.makeText(this, getString(R.string.song_added_to_playlist), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun showCreatePlaylistThenAdd(song: Song) {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.new_playlist_dialog_title))
            .setView(input)
            .setPositiveButton(getString(R.string.ok)) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val playlist = PlaylistRepository.createPlaylist(this, name)
                    PlaylistRepository.addSongToPlaylist(this, playlist.id, song.id)
                    Toast.makeText(this, getString(R.string.song_added_to_playlist), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun refreshFromService() {
        val service = musicService ?: return
        val song = service.getCurrentSong()
        if (song != null) {
            updateNowPlayingUi(song)
            binding.buttonPlayPause.setImageResource(
                if (service.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play
            )
        }
    }

    private fun updateNowPlayingUi(song: Song?) {
        if (song == null) return
        binding.textNowPlayingTitle.text = song.title
        binding.textNowPlayingArtist.text = song.artist
        binding.seekBar.max = song.duration.toInt().coerceAtLeast(1)
        binding.textTotal.text = formatDuration(song.duration)

        val art = AlbumArtLoader.load(this, song.albumId)
        if (art != null) {
            binding.imageAlbumArt.setImageBitmap(art)
        } else {
            binding.imageAlbumArt.setImageResource(R.drawable.ic_music_note)
        }

        songAdapter?.setPlayingSongId(song.id)
    }

    private fun startProgressUpdates() {
        progressRunnable = object : Runnable {
            override fun run() {
                val service = musicService
                if (service != null && !isUserSeeking) {
                    val position = service.getCurrentPosition()
                    binding.seekBar.progress = position
                    binding.textElapsed.text = formatDuration(position.toLong())
                }
                progressHandler.postDelayed(this, 500)
            }
        }
        progressHandler.post(progressRunnable!!)
    }

    private fun formatDuration(millis: Long): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
        return String.format("%d:%02d", minutes, seconds)
    }

    override fun onResume() {
        super.onResume()
        refreshFromService()
        updateModeIcons()
    }

    override fun onDestroy() {
        super.onDestroy()
        progressRunnable?.let { progressHandler.removeCallbacks(it) }
        if (serviceBound) {
            musicService?.listener = null
            unbindService(serviceConnection)
            serviceBound = false
        }
    }
}
