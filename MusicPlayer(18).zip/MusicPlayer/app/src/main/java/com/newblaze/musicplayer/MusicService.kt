package com.newblaze.musicplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.media.app.NotificationCompat as MediaNotificationCompat
import androidx.media.session.MediaButtonReceiver

/**
 * Service qui garde la musique en lecture même quand l'app est en arrière-plan
 * ou l'écran verrouillé, avec une notification affichant les contrôles
 * (précédent / lecture-pause / suivant).
 */
class MusicService : Service() {

    companion object {
        const val CHANNEL_ID = "music_playback_channel"
        const val NOTIFICATION_ID = 1

        const val ACTION_PLAY = "com.newblaze.musicplayer.PLAY"
        const val ACTION_PAUSE = "com.newblaze.musicplayer.PAUSE"
        const val ACTION_NEXT = "com.newblaze.musicplayer.NEXT"
        const val ACTION_PREVIOUS = "com.newblaze.musicplayer.PREVIOUS"
        const val ACTION_STOP = "com.newblaze.musicplayer.STOP"

        const val REPEAT_OFF = 0
        const val REPEAT_ALL = 1
        const val REPEAT_ONE = 2
    }

    interface PlaybackListener {
        fun onSongChanged(song: Song?, index: Int)
        fun onPlaybackStateChanged(isPlaying: Boolean)
        fun onModesChanged(repeatMode: Int, shuffleEnabled: Boolean)
    }

    inner class LocalBinder : Binder() {
        fun getService(): MusicService = this@MusicService
    }

    private val binder = LocalBinder()
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var mediaSession: MediaSessionCompat

    private var playlist: List<Song> = emptyList()
    private var currentIndex: Int = -1

    private var repeatMode: Int = REPEAT_OFF
    private var shuffleEnabled: Boolean = false
    private var shuffledOrder: List<Int> = emptyList()

    private val sleepTimerHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var sleepTimerRunnable: Runnable? = null
    private var sleepTimerEndAt: Long = 0L

    var listener: PlaybackListener? = null

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        mediaSession = MediaSessionCompat(this, "MusicPlayerSession").apply {
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() { resume() }
                override fun onPause() { pause() }
                override fun onSkipToNext() { playNext() }
                override fun onSkipToPrevious() { playPrevious() }
                override fun onStop() { stopPlaybackService() }
            })
            isActive = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> resume()
            ACTION_PAUSE -> pause()
            ACTION_NEXT -> playNext()
            ACTION_PREVIOUS -> playPrevious()
            ACTION_STOP -> stopPlaybackService()
        }
        MediaButtonReceiver.handleIntent(mediaSession, intent)
        return START_NOT_STICKY
    }

    fun setPlaylist(songs: List<Song>) {
        playlist = songs
        shuffledOrder = emptyList()
    }

    fun playAt(index: Int) {
        if (index !in playlist.indices) return
        currentIndex = index
        val song = playlist[index]

        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            setDataSource(applicationContext, Uri.parse(song.uriString))
            setOnPreparedListener {
                it.start()
                updatePlaybackState(true)
                listener?.onPlaybackStateChanged(true)
                startForeground(NOTIFICATION_ID, buildNotification(song, true))
            }
            setOnCompletionListener { onSongCompleted() }
            prepareAsync()
        }

        updateMetadata(song)
        listener?.onSongChanged(song, index)
    }

    fun togglePlayPause() {
        val mp = mediaPlayer ?: return
        if (mp.isPlaying) pause() else resume()
    }

    fun resume() {
        mediaPlayer?.let {
            if (!it.isPlaying) {
                it.start()
                updatePlaybackState(true)
                listener?.onPlaybackStateChanged(true)
                updateNotification(true)
            }
        }
    }

    fun pause() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                updatePlaybackState(false)
                listener?.onPlaybackStateChanged(false)
                updateNotification(false)
            }
        }
    }

    private fun onSongCompleted() {
        when (repeatMode) {
            REPEAT_ONE -> playAt(currentIndex)
            else -> playNext(isAutoAdvance = true)
        }
    }

    fun playNext(isAutoAdvance: Boolean = false) {
        if (playlist.isEmpty()) return

        val nextIndex = computeNextIndex(isAutoAdvance)
        if (nextIndex == null) {
            // Fin de la playlist, pas de répétition : on arrête proprement
            pause()
            return
        }
        playAt(nextIndex)
    }

    fun playPrevious() {
        if (playlist.isEmpty()) return

        if (shuffleEnabled) {
            val pos = shuffledOrder.indexOf(currentIndex)
            val prevPos = if (pos - 1 < 0) shuffledOrder.size - 1 else pos - 1
            playAt(shuffledOrder[prevPos])
        } else {
            val prevIndex = if (currentIndex - 1 < 0) playlist.size - 1 else currentIndex - 1
            playAt(prevIndex)
        }
    }

    private fun computeNextIndex(isAutoAdvance: Boolean): Int? {
        if (shuffleEnabled) {
            if (shuffledOrder.isEmpty() || shuffledOrder.size != playlist.size) {
                regenerateShuffleOrder()
            }
            val pos = shuffledOrder.indexOf(currentIndex)
            val nextPos = pos + 1
            return if (nextPos >= shuffledOrder.size) {
                if (repeatMode == REPEAT_ALL || !isAutoAdvance) {
                    regenerateShuffleOrder()
                    shuffledOrder.firstOrNull()
                } else {
                    null
                }
            } else {
                shuffledOrder[nextPos]
            }
        } else {
            val nextIndex = currentIndex + 1
            return if (nextIndex >= playlist.size) {
                if (repeatMode == REPEAT_ALL || !isAutoAdvance) 0 else null
            } else {
                nextIndex
            }
        }
    }

    private fun regenerateShuffleOrder() {
        shuffledOrder = playlist.indices.shuffled()
    }

    fun toggleShuffle() {
        shuffleEnabled = !shuffleEnabled
        if (shuffleEnabled) regenerateShuffleOrder()
        listener?.onModesChanged(repeatMode, shuffleEnabled)
    }

    fun cycleRepeatMode() {
        repeatMode = when (repeatMode) {
            REPEAT_OFF -> REPEAT_ALL
            REPEAT_ALL -> REPEAT_ONE
            else -> REPEAT_OFF
        }
        listener?.onModesChanged(repeatMode, shuffleEnabled)
    }

    fun getRepeatMode(): Int = repeatMode
    fun isShuffleEnabled(): Boolean = shuffleEnabled

    /**
     * Programme l'arrêt automatique de la lecture après [minutes] minutes.
     * Passer 0 annule la minuterie en cours.
     */
    fun setSleepTimer(minutes: Int) {
        sleepTimerRunnable?.let { sleepTimerHandler.removeCallbacks(it) }
        sleepTimerRunnable = null
        sleepTimerEndAt = 0L

        if (minutes <= 0) return

        sleepTimerEndAt = System.currentTimeMillis() + minutes * 60_000L
        sleepTimerRunnable = Runnable {
            pause()
            sleepTimerEndAt = 0L
        }
        sleepTimerHandler.postDelayed(sleepTimerRunnable!!, minutes * 60_000L)
    }

    fun getSleepTimerRemainingMs(): Long {
        if (sleepTimerEndAt == 0L) return 0L
        return (sleepTimerEndAt - System.currentTimeMillis()).coerceAtLeast(0L)
    }

    fun seekTo(positionMs: Int) {
        mediaPlayer?.seekTo(positionMs)
    }

    fun getCurrentPosition(): Int = mediaPlayer?.currentPosition ?: 0
    fun getDuration(): Int = mediaPlayer?.duration ?: 0
    fun isPlaying(): Boolean = mediaPlayer?.isPlaying == true
    fun getCurrentSong(): Song? = playlist.getOrNull(currentIndex)
    fun getCurrentIndex(): Int = currentIndex

    private fun updatePlaybackState(playing: Boolean) {
        val state = if (playing) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED
        val position = mediaPlayer?.currentPosition?.toLong() ?: 0L
        mediaSession.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(
                    PlaybackStateCompat.ACTION_PLAY or
                        PlaybackStateCompat.ACTION_PAUSE or
                        PlaybackStateCompat.ACTION_PLAY_PAUSE or
                        PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                        PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
                        PlaybackStateCompat.ACTION_SEEK_TO
                )
                .setState(state, position, 1f)
                .build()
        )
    }

    private fun updateMetadata(song: Song) {
        val art = AlbumArtLoader.load(this, song.albumId)
        mediaSession.setMetadata(
            MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, song.title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, song.artist)
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, song.duration)
                .apply { if (art != null) putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, art) }
                .build()
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Lecture musicale",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Contrôles de lecture de musique"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(song: Song, isPlaying: Boolean): Notification {
        val art = AlbumArtLoader.load(this, song.albumId)

        val playPauseIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseAction = if (isPlaying) ACTION_PAUSE else ACTION_PLAY

        val openAppIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(song.title)
            .setContentText(song.artist)
            .setLargeIcon(art)
            .setContentIntent(contentPendingIntent)
            .addAction(android.R.drawable.ic_media_previous, "Précédent", servicePendingIntent(ACTION_PREVIOUS))
            .addAction(playPauseIcon, "Lecture/Pause", servicePendingIntent(playPauseAction))
            .addAction(android.R.drawable.ic_media_next, "Suivant", servicePendingIntent(ACTION_NEXT))
            .setStyle(
                MediaNotificationCompat.MediaStyle()
                    .setMediaSession(mediaSession.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .setOngoing(isPlaying)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(isPlaying: Boolean) {
        val song = getCurrentSong() ?: return
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(song, isPlaying))
    }

    private fun servicePendingIntent(action: String): PendingIntent {
        val intent = Intent(this, MusicService::class.java).setAction(action)
        return PendingIntent.getService(
            this, action.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun stopPlaybackService() {
        mediaPlayer?.release()
        mediaPlayer = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        mediaPlayer?.release()
        mediaPlayer = null
        mediaSession.release()
        sleepTimerRunnable?.let { sleepTimerHandler.removeCallbacks(it) }
        super.onDestroy()
    }
}
