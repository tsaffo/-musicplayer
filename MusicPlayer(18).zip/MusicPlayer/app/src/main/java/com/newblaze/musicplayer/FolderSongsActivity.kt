package com.newblaze.musicplayer

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.newblaze.musicplayer.databinding.ActivityFolderSongsBinding

class FolderSongsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFolderSongsBinding
    private var folderSongs: List<Song> = emptyList()

    private var musicService: MusicService? = null
    private var serviceBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as MusicService.LocalBinder
            musicService = binder.getService()
            serviceBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            musicService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFolderSongsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val folderName = intent.getStringExtra("folder_name") ?: ""
        binding.textFolderTitle.text = folderName

        val allSongs = MusicRepository.getAllSongs(this)
        val folders = MusicRepository.groupByFolder(allSongs)
        folderSongs = folders.find { it.first == folderName }?.second ?: emptyList()

        binding.buttonBack.setOnClickListener { finish() }
        binding.recyclerFolderSongs.layoutManager = LinearLayoutManager(this)

        val adapter = SongAdapter(
            folderSongs,
            onSongClick = { song ->
                val index = folderSongs.indexOf(song)
                if (index != -1) {
                    musicService?.setPlaylist(folderSongs)
                    musicService?.playAt(index)
                }
            },
            onAddToPlaylistClick = { song -> showAddToPlaylistDialog(song) }
        )
        binding.recyclerFolderSongs.adapter = adapter

        val serviceIntent = Intent(this, MusicService::class.java)
        startService(serviceIntent)
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun showAddToPlaylistDialog(song: Song) {
        val playlists = PlaylistRepository.getAll(this)
        val options = playlists.map { it.name }.toMutableList()
        options.add(getString(R.string.create_new_playlist_option))

        android.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.add_to_playlist_dialog_title))
            .setItems(options.toTypedArray()) { _, which ->
                if (which == options.size - 1) {
                    val input = android.widget.EditText(this)
                    android.app.AlertDialog.Builder(this)
                        .setTitle(getString(R.string.new_playlist_dialog_title))
                        .setView(input)
                        .setPositiveButton(getString(R.string.ok)) { _, _ ->
                            val name = input.text.toString().trim()
                            if (name.isNotEmpty()) {
                                val playlist = PlaylistRepository.createPlaylist(this, name)
                                PlaylistRepository.addSongToPlaylist(this, playlist.id, song.id)
                            }
                        }
                        .setNegativeButton(getString(R.string.cancel), null)
                        .show()
                } else {
                    val playlist = playlists[which]
                    PlaylistRepository.addSongToPlaylist(this, playlist.id, song.id)
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (serviceBound) {
            unbindService(serviceConnection)
            serviceBound = false
        }
    }
}
