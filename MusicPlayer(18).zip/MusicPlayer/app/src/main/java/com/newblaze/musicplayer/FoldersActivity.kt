package com.newblaze.musicplayer

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.newblaze.musicplayer.databinding.ActivityFoldersBinding

class FoldersActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFoldersBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFoldersBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerFolders.layoutManager = LinearLayoutManager(this)

        val allSongs = MusicRepository.getAllSongs(this)
        val folders = MusicRepository.groupByFolder(allSongs)

        binding.textEmpty.visibility = if (folders.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE

        val adapter = FolderAdapter(folders) { folderName, _ ->
            val intent = Intent(this, FolderSongsActivity::class.java)
            intent.putExtra("folder_name", folderName)
            startActivity(intent)
        }
        binding.recyclerFolders.adapter = adapter

        setupBottomNav()
    }

    private fun setupBottomNav() {
        binding.bottomNavigation.selectedItemId = R.id.nav_folders
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_library -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_playlists -> {
                    startActivity(Intent(this, PlaylistsActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_folders -> true
                else -> false
            }
        }
    }
}
