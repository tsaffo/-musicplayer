package com.newblaze.musicplayer

import android.content.Context
import android.provider.MediaStore
import java.io.File

object MusicRepository {

    fun getAllSongs(context: Context): List<Song> {
        val songs = mutableListOf<Song>()

        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        context.contentResolver.query(
            collection,
            projection,
            selection,
            null,
            sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val dateAddedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Titre inconnu"
                val artist = cursor.getString(artistCol) ?: "Artiste inconnu"
                val duration = cursor.getLong(durationCol)
                val albumId = cursor.getLong(albumIdCol)
                val path = cursor.getString(dataCol) ?: ""
                val dateAdded = cursor.getLong(dateAddedCol)
                val uri = "$collection/$id"

                // On ignore les morceaux situés dans un dossier caché
                // (nom commençant par un point, ou contenant un fichier .nomedia)
                if (isInHiddenFolder(path)) continue

                songs.add(Song(id, title, artist, duration, uri, albumId, path, dateAdded))
            }
        }

        return songs
    }

    private fun isInHiddenFolder(path: String): Boolean {
        if (path.isEmpty()) return false
        val parent = File(path).parentFile ?: return false

        // Dossier dont le nom commence par un point (convention "caché")
        if (parent.name.startsWith(".")) return true

        // Dossier contenant un fichier .nomedia (convention Android standard)
        if (File(parent, ".nomedia").exists()) return true

        return false
    }

    /**
     * Regroupe les morceaux par dossier parent, pour l'onglet "Dossiers".
     */
    fun groupByFolder(songs: List<Song>): List<Pair<String, List<Song>>> {
        return songs
            .groupBy { song ->
                File(song.path).parentFile?.name ?: "Musique"
            }
            .toList()
            .sortedBy { it.first.lowercase() }
    }
}
