package com.newblaze.musicplayer

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.newblaze.musicplayer.databinding.ItemFolderBinding

class FolderAdapter(
    private var folders: List<Pair<String, List<Song>>>,
    private val onClick: (String, List<Song>) -> Unit
) : RecyclerView.Adapter<FolderAdapter.FolderViewHolder>() {

    inner class FolderViewHolder(val binding: ItemFolderBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FolderViewHolder {
        val binding = ItemFolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FolderViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FolderViewHolder, position: Int) {
        val (folderName, songs) = folders[position]
        holder.binding.textFolderName.text = folderName
        holder.binding.textFolderCount.text = "${songs.size} morceau(x)"
        holder.binding.root.setOnClickListener { onClick(folderName, songs) }
    }

    override fun getItemCount() = folders.size

    fun updateData(newFolders: List<Pair<String, List<Song>>>) {
        folders = newFolders
        notifyDataSetChanged()
    }
}
